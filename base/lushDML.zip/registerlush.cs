MissionRegDis( LushRocks, lrock1);
MissionRegDis( LushRocks, lrock2);
MissionRegDis( LushRocks, lrock3);
MissionRegDis( LushRocks, lrock4);
MissionRegDis( LushRocks, lrock5);
MissionRegDis( LushRocks, lrock6);
