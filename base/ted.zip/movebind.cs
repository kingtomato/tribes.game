Ted::flymode 2
Ted::flymodeTopView 1
echo "   Move mode activated"
