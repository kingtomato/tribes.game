LSEditor $Ted::mainWindow
flushTextureCache
