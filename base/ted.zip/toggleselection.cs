not Ted::selVisible
Ted::toggleSelection
