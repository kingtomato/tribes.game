Ted::flymode 1
Ted::flymodeTopView 0
echo "   Fly mode activated in 3d view"
