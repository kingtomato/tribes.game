listFiles Ted::fileName
if test $dlgResult != [cancel]
   set Ted::currFile $Ted::fileName
endif

