newClient
focusClient
newCanvas ClientWindow "Client Window" 640 480 1
newCamera ClientCamera ClientWindow -1
