editBox HeightInc "Enter a new value for the height increment" Ted::heightInc
