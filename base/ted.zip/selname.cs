Ted::listSelections Ted::selectionName
if test $dlgResult != [cancel]
   Ted::selectByName $Ted::selectionName
endif
