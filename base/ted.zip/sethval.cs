editBox HeightVal "Enter a new value for the height variable" Ted::heightVal
