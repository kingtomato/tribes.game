Ted::flymode 0
Ted::flymodeTopView 0
echo "   Selection mode"
