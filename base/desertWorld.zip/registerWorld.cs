            exec("registerdesert.cs");
            echo("registered desertDML.vol");
            exec("registersavana.cs");
            echo("registered savanaDML.vol");
            exec("registerhuman1.cs");
            echo("registered human1DML.vol");
            exec("registertitan.cs");
            echo("registered titanDML.vol");
