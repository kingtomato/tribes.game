MissionRegDis( Desert, dbridge );
MissionRegDis( Desert, dcolumn );
MissionRegDis( Desert, dcolumn1 );
MissionRegDis( Desert, drock );
MissionRegDis( Desert, drock1 );