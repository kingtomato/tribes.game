            newObject(iceDML, SimVolume, "iceDML.vol");
            addToSet("MissionGroup\\Volumes", iceDML);
            echo("added iceDML.vol");
            newObject(savanaDML, SimVolume, "savanaDML.vol");
            addToSet("MissionGroup\\Volumes", savanaDML);
            echo("added savanaDML.vol");
            newObject(human1DML, SimVolume, "human1DML.vol");
            addToSet("MissionGroup\\Volumes", human1DML);
            echo("added human1DML.vol");
