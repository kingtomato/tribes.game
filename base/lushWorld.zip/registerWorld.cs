            exec("registerlush.cs");
            echo("registered lushDML.vol");
            exec("registersavana.cs");
            echo("registered savanaDML.vol");
            exec("registerhuman1.cs");
            echo("registered human1DML.vol");
